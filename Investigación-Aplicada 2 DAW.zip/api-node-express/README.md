
# Instalacion del proyecto

## Tener instalado node js para empezar


Ejecutar el comando ``` npm install ``` para instalar los paquetes de node

## Una vez terminado, se procede a levantar el servidor http
``` node index o npm start ```


## El servidor se ejecuta sobre el puerto 3000
``` http://localhost:3000/ ```

