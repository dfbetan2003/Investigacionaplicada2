
//se que podre hacer esto por messi

const fs = require('fs');
const { response, request } = require('express');
const express = require('express');
const app = express();

// Se usa para que las peticiones post y delete reconozcan peticiones JSON
app.use(express.json());

let materiasTecnico = [];
let materiasIngeniera = [];
let inscripciones = [];

function leerJson() {
    // Lee el archivo JSON
    fs.readFile("datos/materiasTecnico.json", 'utf8', (error, data) => {
        materiasTecnico = JSON.parse(data);
    });

    fs.readFile("datos/materiasIngenieria.json", 'utf8', (error, data) => {
        materiasIngeniera = JSON.parse(data);
    });
}

leerJson();

function obtenerMateriasPorCiclo(numeroCiclo) {
    // Spread operator, combina el array de materias de ambas carreras haciendo un array de objetos
    if (numeroCiclo == 1) {
        return [...materiasTecnico.ciclo1.materias, ...materiasIngeniera.ciclo1.materias];
    }

    if (numeroCiclo == 2) {
        return [...materiasTecnico.ciclo2.materias, ...materiasIngeniera.ciclo2.materias];
    }
}



function combinarMaterias() {
    return [...obtenerMateriasPorCiclo(1), ...obtenerMateriasPorCiclo(2)];
}



// Declaracion de rutas
app.get('/', (req, res = response) => {
    res.send("Bienvenido a la ruta de inicio api by grupo Dinamita");
});

app.get('/obtenerCarreras', (req, res = response) => {
    res.json([materiasTecnico, materiasIngeniera]);
});

app.get("/requisitos-carrera/:codigo", (req = request, res = response) => {
    let parametros = req.params;
    let codigo = parametros.codigo;


    let materias = combinarMaterias();
    //Se filtran solo materias de las carreras
    let buscarMateria = materias.find(materiaCa => materiaCa.codigo == codigo);

    if (buscarMateria == null || buscarMateria == undefined) {
        return res.json("Materia no encontrada");
    }

    return res.json({
        materia: buscarMateria
    });
});

app.get("/materias-por-ciclo/:ciclo", (req = request, res = response) => {
    let parametros = req.params;
    let ciclo = parametros.ciclo;

    if (ciclo != 1 && ciclo != 2) {
        return res.json("Ciclo no valido", ciclo)
    }

    return res.json({
        materias: obtenerMateriasPorCiclo(ciclo)
    })
});

app.post("/inscribir", (req, res = response) => {
    /**
        JSON Recibe
        {
            "carrera": "tecnico",
            "ciclo": 1,
            "materias": [
                {
                    "codigo": "PAL404",
                    "cantidadUv": 4
                }
            ]
        }
     */
    let body = req.body;
    let materiasRequest = req.body.materias;

    if (body.carrera == "tecnico") {
        let ciclo = body.ciclo;
        let uvValidas = 0;
        if (ciclo == 1) {
            uvValidas = materiasTecnico.ciclo2.maximoUv;
        }
        if (ciclo == 2) {
            uvValidas = materiasTecnico.ciclo2.maximoUv;
        }
        // if (ciclo == 1) {
        //     uvValidas = materiasIngeniera.ciclo2.maximoUv;
        // }
        // if (ciclo == 2) {
        //     uvValidas = materiasIngeniera.ciclo2.maximoUv;
        // }

        let sumaUv = 0;

        materiasRequest.forEach(materia => {
            sumaUv += materia.cantidadUv
        });

        if (sumaUv > uvValidas) {
            return res.json("Sobrepaso el limite de UV");
        }

        materiasRequest.forEach(materia => {
            let existeMateria = inscripciones.find(function (ins) {
                return ins.materia == materia.codigo
            });
            if (!existeMateria) {
                inscripciones.push(
                    {
                        ciclo: ciclo,
                        carrera: "tecnico",
                        materia: materia.codigo,
                        uvMateria: materia.cantidadUv
                    }

                );
                // if (!existeMateria) {
                //     inscripciones.push(
                //         {
                //             ciclo: ciclo,
                //             carrera: "ingenieria",
                //             materia: materia.codigo,
                //             uvMateria: materia.cantidadUv
                //         }
                //     )
                // }
            }
        });

    }


    return res.json({
        inscripciones
    });
});

app.delete("/eliminar-materia-por-ciclo", (req, res = response) => {
    /**
     * JSON recibe
    {
        "ciclo": 1,
        "codigo": "PAL404"
    }
     */
    let data = req.body;
    let codigo = data.codigo;
    let ciclo = data.ciclo;

    inscripciones = inscripciones.filter(function (ins) {
        // Buscar ciclo y no incluir la materia que se esta eliminando
        return ins.ciclo == ciclo && ins.materia != codigo;
    });

    return res.json({
        inscripciones,
        codigo,
        ciclo
    });
});

// localhost:3000/
app.listen(3000, () => {
    console.log("Servidor levantado en el puerto: ", 3000);
});
//que bendicion haber terminado inge
